export let IOSApp = {
    screen: {
        screen: 'dyno.Home',
        title: 'Home'
    },
    // drawer: {
    //       left: {
    //           screen: 'dyno.LeftDrawer',
    //           fixedWidth: 500
    //       }
    // }
}