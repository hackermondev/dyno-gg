package com.dyno;
import com.reactnativenavigation.controllers.SplashActivity;

import com.facebook.react.ReactActivity;

public class MainActivity extends SplashActivity {
    
}
