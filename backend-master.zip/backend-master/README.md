## Generate an auth-key

`openssl genrsa -out jwtRS256.key 2048`
