module.exports = function (server, User) {
	server.get('/api/users', (req, res, next) => {

	});
	server.get('/api/users/:id', (req, res, next) => {

	});
	server.put('/api/users/:id', (req, res, next) => {

	});
	server.delete('/api/users/:id', (req, res, next) => {

	});
};
