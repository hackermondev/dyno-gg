Dyno-automod
============
