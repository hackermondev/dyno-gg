# Fun commands for Dyno

Commands should always return a promise.