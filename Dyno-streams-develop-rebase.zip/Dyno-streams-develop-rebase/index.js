'use strict';

const streamService = require('./lib/StreamService.js');

streamService.start();