import React from 'react';

export default class Searchbar extends React.Component {
	render() {
		return <p>basic stuff</p>;
	}
}
