export default interface WebhookConfig {
	id: string;
	token: string;
}
