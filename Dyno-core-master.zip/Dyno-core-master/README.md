Core module for Dyno
=========================
