Translations for Dyno
=====================