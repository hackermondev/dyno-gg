import {Service} from './Service';

const service = new Service();
service.start();
