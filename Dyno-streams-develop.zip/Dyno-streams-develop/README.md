# Dyno Streams

The service that will handle stream alerts for Dyno with the power of webhooks and polling!