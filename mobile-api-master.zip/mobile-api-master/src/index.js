const Client = require('./core/Client');
const client = new Client(); // eslint-disable-line

// setInterval(() => process.exit(), 3600 * 1000);
