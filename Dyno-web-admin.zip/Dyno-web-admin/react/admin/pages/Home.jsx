import react from 'react';

export default class Home extends react.Component {
    render() {
        return (<div className='column'></div>)
    }
}