module.exports = {
    serverSchema: require('./server.schema')
}
