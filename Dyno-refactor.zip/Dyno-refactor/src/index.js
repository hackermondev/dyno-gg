module.exports = {
	Dyno: require('./core/Dyno'),
	IPCManager: require('./core/managers/IPCManager'),
	PermissionsManager: require('./core/managers/PermissionsManager'),
	WebhookManager: require('./core/managers/WebhookManager'),
};
