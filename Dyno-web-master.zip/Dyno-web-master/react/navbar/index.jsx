import React from 'react';
import ReactDOM from 'react-dom';
import Navbar from './Navbar.jsx';

ReactDOM.render(
    <Navbar />,
    document.getElementById('navbar-mount'),
);
